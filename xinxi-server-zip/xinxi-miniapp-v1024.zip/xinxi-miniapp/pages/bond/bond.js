Page({
  data: {
    userName: '小守', mbti: '', relation: '',
    activeTab: 'mutual', bonds: [], mutualBonds: [], quietBonds: []
  },
  onShow() {
    this.getTabBar && this.getTabBar().setData({ selected: 3 })
    getApp().ensureLogin().then(() => this.loadData()).catch(() => {})
  },
  async loadData() {
    var that = this
    const app = getApp()
    if (app.globalData.user) {
      const u = app.globalData.user
      that.setData({ userName: u.nickname || '小守', mbti: u.mbti || '', relation: u.relation || '' })
    }
    try {
      const bonds = await app.request({ url: '/api/bonds' })
      that.setData({
        bonds,
        mutualBonds: bonds.filter(b => !b.silent),
        quietBonds: bonds.filter(b => b.silent)
      })
    } catch (e) { console.error('加载失败', e) }
  },
  switchTab(e) { this.setData({ activeTab: e.currentTarget.dataset.tab }) },
  addBond() {
    var that = this
    wx.showModal({
      title: '建立守望', editable: true, placeholderText: '输入对方姓名',
      success: async res => {
        if (!res.confirm || !res.content) return
        const app = getApp()
        try {
          await app.request({ url: '/api/bonds', method: 'POST', data: { name: res.content, relation: '朋友', type: '相伴' } })
          that.loadData()
        } catch (e) { wx.showToast({ title: '添加失败', icon: 'none' }) }
      }
    })
  },
  sendEcho(e) {
    var that = this
    wx.showModal({
      title: '发送回响', editable: true, placeholderText: '想说的话...',
      success: async res => {
        if (!res.confirm || !res.content) return
        const app = getApp()
        try {
          await app.request({ url: '/api/messages', method: 'POST', data: { toUserId: app.globalData.user.id, text: res.content } })
          wx.showToast({ title: '回响已发出', icon: 'success' })
        } catch (e) { wx.showToast({ title: '发送失败', icon: 'none' }) }
      }
    })
  }
})
