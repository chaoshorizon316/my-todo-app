// 心汐 · 微信云托管 callContainer 架构
App({
  globalData: {
    token: '',
    user: null,
    loggedIn: false,
    loginCallbacks: [],
    cloudEnv: 'prod-d4gkxxsyj1dd985c8',
    serviceName: 'express-cd9z'
  },

  onLaunch() {
    try {
      wx.cloud.init({
        env: this.globalData.cloudEnv,
        traceUser: true
      })
    } catch (e) {
      console.error('云开发初始化失败', e)
    }

    const token = wx.getStorageSync('token')
    const user = wx.getStorageSync('user')
    if (token) {
      this.globalData.token = token
      this.globalData.user = user
      this.globalData.loggedIn = true
    }
  },

  login(cb) {
    if (this.globalData.loggedIn && this.globalData.token) {
      cb && cb(null, this.globalData.user)
      return
    }
    if (this.globalData.loginCallbacks.length > 0) {
      this.globalData.loginCallbacks.push(cb)
      return
    }
    this.globalData.loginCallbacks.push(cb)

    wx.login({
      success: res => {
        this.callContainer({
          url: '/api/login',
          method: 'POST',
          data: { code: res.code }
        }).then(r => {
          if (r.token) {
            this.globalData.token = r.token
            this.globalData.user = r.user
            this.globalData.loggedIn = true
            wx.setStorageSync('token', r.token)
            wx.setStorageSync('user', r.user)
          }
          const cbs = this.globalData.loginCallbacks
          this.globalData.loginCallbacks = []
          cbs.forEach(fn => fn && fn(null, r))
        }).catch(err => {
          const cbs = this.globalData.loginCallbacks
          this.globalData.loginCallbacks = []
          cbs.forEach(fn => fn && fn(err))
        })
      },
      fail: () => {
        const cbs = this.globalData.loginCallbacks
        this.globalData.loginCallbacks = []
        cbs.forEach(fn => fn && fn('微信登录失败'))
      }
    })
  },

  ensureLogin() {
    if (this.globalData.loggedIn && this.globalData.token) {
      return Promise.resolve()
    }
    return new Promise((resolve, reject) => {
      this.login((err) => {
        if (err) reject(err)
        else resolve()
      })
    })
  },

  // callContainer 带冷启动重试
  callContainer(options, retries) {
    var maxRetries = (typeof retries === 'number') ? retries : 2
    var self = this

    function tryCall(resolve, reject, attempt) {
      var header = {}
      if (self.globalData.token) {
        header['Authorization'] = 'Bearer ' + self.globalData.token
      }
      if (options.header) {
        Object.assign(header, options.header)
      }

      wx.cloud.callContainer({
        config: { env: self.globalData.cloudEnv },
        path: options.url,
        header: Object.assign({ 'X-WX-SERVICE': self.globalData.serviceName }, header),
        method: options.method || 'GET',
        data: options.data || {},
        success: function(res) {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(res.data)
          } else if (res.statusCode === 401) {
            self.globalData.loggedIn = false
            self.globalData.token = ''
            self.login(function(err) {
              if (err) return reject(err)
              header['Authorization'] = 'Bearer ' + self.globalData.token
              wx.cloud.callContainer({
                config: { env: self.globalData.cloudEnv },
                path: options.url,
                header: Object.assign({ 'X-WX-SERVICE': self.globalData.serviceName }, header),
                method: options.method || 'GET',
                data: options.data || {},
                success: function(r2) {
                  if (r2.statusCode >= 200 && r2.statusCode < 300) resolve(r2.data)
                  else reject(r2.data)
                },
                fail: reject
              })
            })
          } else {
            reject(res.data)
          }
        },
        fail: function(err) {
          console.warn('callContainer failed, attempt ' + (attempt + 1) + '/' + (maxRetries + 1), err)
          if (attempt < maxRetries) {
            setTimeout(function() { tryCall(resolve, reject, attempt + 1) }, 3000)
          } else {
            reject(err)
          }
        }
      })
    }

    return new Promise(function(resolve, reject) {
      tryCall(resolve, reject, 0)
    })
  },

  request(options) {
    return this.callContainer(options)
  }
})
